<?php 
include("inc/connect.php");
include("inc/chkAuth.php");

$dt=date('Y-m-d');

$sql="select count(*) from payout where closing_date='$dt' and user_id='$id'";
$cntDailyPay=ReturnAnyValue($conn,$sql);

if($cntDailyPay==0)
{

$sql="SELECT pan_no FROM `kyc_detail` where user_id=".$id;
$checkPan=ReturnAnyValue($conn,$sql);

	if($checkPan=== NULL)
	{
	  $sql="select * from settings where id=1";
	  $rssetting=mysqli_query($conn,$sql);
	  $rowsetting=mysqli_fetch_array($rssetting);
	  $tds=$rowsetting['tds_no_pan'];
	  $adminCharge=$rowsetting['admin_charge'];
	  
	}
	else
	{
	  $sql="select * from settings where id=1";
	  $rssetting=mysqli_query($conn,$sql);
	  $rowsetting=mysqli_fetch_array($rssetting);
	  $tds=$rowsetting['tds'];
	  $adminCharge=$rowsetting['admin_charge'];
	}

//payout gen for cashback and level income

$sql="SELECT SUM(inc_amt) as dailysum,user_id FROM `daily_income` WHERE status='0' and inc_date='$dt' GROUP BY user_id";
$rs=mysqli_query($conn,$sql);


while($row=mysqli_fetch_array($rs))
		
		{

			$dailySum=$row['dailysum'];
			$id=$row['user_id'];


			

					$amount=$dailySum;


					$tdsAmt=($amount*$tds)/100;
					$adminChargeAmt=($amount*$adminCharge)/100;

					$netAmount=$amount-($amount*($tds+$adminCharge)/100);

					
					$sql="select cur_bal from payout where user_id=".$id." order by pid DESC limit 1";
					$oldBal=ReturnAnyValue($conn,$sql);
					if($oldBal=="")
					{
						$oldBal=0;
					}
					$newBal=$oldBal+$netAmount;

					$sql="insert into payout(user_id,amount,closing_date,tds,admin_charge,net_amt,prev_bal,cur_bal) values('$id','$amount','$dt','$tdsAmt','$adminChargeAmt','$netAmount','$oldBal','$newBal')";
					echo $sql;
						

					if(mysqli_query($conn,$sql))
					    {
					    	$sql="UPDATE `daily_income` SET `status` = '2' WHERE inc_date='$dt' and user_id=".$id;
					    	mysqli_query($conn,$sql);
					    	

					    	
					        
					    }

					 else 
					    {
					        echo "error:".$sql."<br>".mysqli_error($conn);
					    }


			    
		}

		//payout generated for direct income

		$sql="SELECT SUM(inc_amt) as dirsum,user_id FROM `gen_income` WHERE status='0' and inc_date='$dt' GROUP BY user_id";

		$rs=mysqli_query($conn,$sql);


	while($row=mysqli_fetch_array($rs))
		
		{

			$directSum=$row['dirsum'];
			$id=$row['user_id'];


	

					$amount=$directSum;


					$tdsAmt=($amount*$tds)/100;
					$adminChargeAmt=($amount*$adminCharge)/100;

					$netAmount=$amount-($amount*($tds+$adminCharge)/100);

					
					$sql="select cur_bal from payout where user_id=".$id." order by pid DESC limit 1";
					$oldBal=ReturnAnyValue($conn,$sql);
					
					if($oldBal=="")
					{
						$oldBal=0;
					}
					$newBal=$oldBal+$netAmount;

					$sql="select count(*) as cnt from payout where user_id=".$id." and closing_date='$dt'";
					$cnt=ReturnAnyValue($conn,$sql);

					if($cnt>0)
					{
						$sql="update payout set amount=amount+'$amount',tds=tds+'$tdsAmt',admin_charge=admin_charge+'$adminChargeAmt',net_amt=net_amt+'$netAmount',prev_bal='$oldBal',cur_bal='$newBal' where user_id=".$id." 
						and closing_date='$dt'";
						echo $sql;
					}
					else
					{

					$sql="insert into payout(user_id,amount,closing_date,tds,admin_charge,net_amt,prev_bal,cur_bal) values('$id','$amount','$dt','$tdsAmt','$adminChargeAmt','$netAmount','$oldBal','$newBal')";
					}

					if(mysqli_query($conn,$sql))
					    {
					    	

					    	$sql="UPDATE `gen_income` SET `status` = '2' WHERE inc_date='$dt' and user_id=".$id;
					    	mysqli_query($conn,$sql);
					    	
					        
					    }

					 else 
					    {
					        echo "error:".$sql."<br>".mysqli_error($conn);
					    }


			    
		}

  }

?>