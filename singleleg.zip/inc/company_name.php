<?php

$companyName="Dhanyog";
echo $companyName;
?>